Version 1.3
KSP Forum thread: http://forum.kerbalspaceprogram.com/index.php?/topic/59009-1
Installation:

Place the GameData folder in the main KSP folder. Folder structure should be:
Kerbal Space Program/GameData/DMagicOrbitalScience/...

Module Manager* required for some contracts and additional functions - *Not included
http://forum.kerbalspaceprogram.com/threads/55219

Universal Storage* recommended for full part compatibility - *Not included
http://forum.kerbalspaceprogram.com/threads/75129

Parts may require repurchasing in the R&D center for career mode saves.

------------------

Source code available on Github: https://github.com/DMagic1/Orbital-Science