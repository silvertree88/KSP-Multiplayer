Version 0.19
	KSP V 1.3

Installation:

Place the GameData folder in the main KSP folder.

Use the reference.cfg file to check the fields available, their function and their default values. The values shown are those for my magnetometer.

Add the module DMModuleScienceAnimateGeneric to your part.cfg file and configure as desired.

